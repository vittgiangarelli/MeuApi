﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class PedidoController : ApiController
    {
        [HttpGet]
        public List<Pedido> ObterPedidos()
        {
            Pedido p;

            List<Pedido> pedidos = new List<Pedido>();

            p = new Pedido();
            p.Id = 1;
            p.Descricao = "balde de frango";
            p.ValorTotal = 50;
            pedidos.Add(p);

            p = new Pedido();
            p.Id = 2;
            p.Descricao = "balde de batata";
            p.ValorTotal = 20;
            pedidos.Add(p);

            p = new Pedido();
            p.Id = 3;
            p.Descricao = "balde de piroca de frango";
            p.ValorTotal = 100;
            pedidos.Add(p);

            return pedidos;
        }
    }
}
