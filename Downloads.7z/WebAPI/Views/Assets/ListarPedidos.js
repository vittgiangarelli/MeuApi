﻿var botao;

botao = document.getElementById("btn1");

botao.onclick = function () {
    //if ($.active)

    $.ajax({
        url: "http://localhost:50347/api/Pedido/ObterPedidos",
        method: 'GET',
        async: 'true',
        dataType: "json",
        success: function (data) {
            debugger;


        },
        error: function (msg) {
            debugger;
        }
    });
}